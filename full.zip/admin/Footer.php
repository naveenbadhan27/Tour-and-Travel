<script src="./assets/js/plugins/popper.min.js"></script>
<script src="./assets/js/plugins/simplebar.min.js"></script>
<script src="./assets/js/plugins/bootstrap.min.js"></script>
<script src="./assets/js/icon/custom-font.js"></script>
<script src="./assets/js/script.js"></script>
<script src="./assets/js/theme.js"></script>
<script src="./assets/js/plugins/feather.min.js"></script>


<script>
    layout_change('light');
</script>

<script>
    font_change('Roboto');
</script>

<script>
    change_box_container('false');
</script>

<script>
    layout_caption_change('true');
</script>

<script>
    layout_rtl_change('false');
</script>

<script>
    preset_change('preset-1');
</script>

<script src="./assets/js/plugins/apexcharts.min.js"></script>
<script src="./assets/js/pages/dashboard-default.js"></script>