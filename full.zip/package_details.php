<?php
session_start();

include "./config.php";

$package_id = $_GET['id'];

$sql_latest = "SELECT * FROM travel_packages tp
LEFT JOIN hotels h ON tp.hotel_id = h.id
LEFT JOIN cabs c ON tp.cab_id = c.id
LEFT JOIN flights f ON tp.flight_id = f.id
LEFT JOIN package_images pi ON tp.id = pi.package_id AND pi.is_cover = 1
WHERE tp.id = ?";

$imgss = "SELECT * FROM package_images pi WHERE package_id = '$package_id'";
// $result_latest = $db->query($sql_latest);
// $package = $result_latest->fetch_all(MYSQLI_ASSOC);


$stmt = $db->prepare($sql_latest);
$stmt->bind_param("i", $package_id);
$stmt->execute();
$result = $stmt->get_result();
$package = $result->fetch_assoc();
echo $package;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>WanderEase Travels</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@200;300;400;500;600&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-secondary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <?php
    include "Header.php";
    ?>

    <!-- Contact Start -->
    <div class="container-fluid contact overflow-hidden pb-5">
        <div class="container-fluid py-5">
            <div class="office pt-5">
                <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="sub-style">
                        <h5 class="sub-title text-primary px-3">
                            <?= htmlspecialchars($package['package_name']) ?>
                        </h5>
                    </div>

                    <div class="mt-5">

                        <div class="row m-0">
                            <div class="col-lg-4">
                                <img src="admin/<?= htmlspecialchars($package['image_path']) ?>"
                                    class="img-fluid rounded shadow"
                                    alt="<?= htmlspecialchars($package['package_name']) ?>">
                            </div>
                            <div class="col-lg-8 text-start">
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <button class="btn btn-success btn-lg float-end" id="buyNowBtn">
                                        Book this Trip
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-danger btn-lg float-end"
                                        onclick="alert('Please log in to proceed with booking!'); window.location.href='Login Register.php';">
                                        Book this Trip
                                    </button>
                                <?php endif; ?>
                                <h5 class="text-muted"><?= htmlspecialchars($package['package_type']) ?>
                                    Package
                                </h5>

                                <div class="mt-4">
                                    <p><strong>Category:</strong> <?= htmlspecialchars($package['package_type']) ?></p>
                                    <p><strong>Location:</strong> <?= htmlspecialchars($package['city']) ?></p>
                                    <p><strong>Duration:</strong> <?= htmlspecialchars($package['no_of_days']) ?> Days
                                    </p>
                                    <p><strong>Price:</strong> ₹<?= number_format($package['total_amount'], 2) ?></p>
                                    <p><strong>Description:</strong>
                                        <?= nl2br(htmlspecialchars($package['activities'])) ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 text-start">
                            <h4>Related Images</h4>
                            <div class="row">
                                <?php
                                $qr = $db->query($imgss);
                                while ($image = mysqli_fetch_array($qr)) {
                                    ?>
                                    <div class="col-md-2 mb-3">
                                        <img src="admin/<?= htmlspecialchars($image['image_path']) ?>"
                                            class="img-fluid rounded shadow" alt="Package Image" style="object-fit: cover;">
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>

                        <hr class="my-5" />

                        <div class="row m-0 align-items-center">
                            <div class="col-lg-3">
                                <img src="https://cdn-icons-png.flaticon.com/512/6008/6008287.png" alt="Hotel"
                                    class="img-fluid">
                            </div>
                            <div class="col-lg-9 text-start">

                                <!-- Hotel Details -->
                                <div class="">
                                    <h4>Hotel Details</h4>
                                    <p><strong>Name:</strong> <?= htmlspecialchars($package['name']) ?></p>
                                    <p><strong>Email:</strong> <?= htmlspecialchars($package['email']) ?></p>
                                    <p><strong>Contact:</strong> <?= htmlspecialchars($package['contact']) ?></p>
                                    <p><strong>Address:</strong> <?= htmlspecialchars($package['address']) ?></p>
                                </div>
                            </div>
                        </div>

                        <hr class="my-5" />

                        <div class="row m-0 align-items-center">
                            <div class="col-lg-3">
                                <img src="https://cdn-icons-png.flaticon.com/512/7804/7804371.png" alt="Hotel"
                                    class="img-fluid">
                            </div>
                            <div class="col-lg-9 text-start">
                                <!-- Cab Details -->
                                <div class="">
                                    <h4>Cab Details</h4>
                                    <p><strong>Name:</strong> <?= htmlspecialchars($package['cab_name']) ?></p>
                                    <p><strong>Type:</strong> <?= htmlspecialchars($package['cab_type']) ?></p>
                                    <p><strong>Price:</strong> ₹<?= number_format($package['fare_per_km'], 2) ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="row m-0 align-items-center">
                            <div class="col-lg-3">
                                <img src="https://cdn-icons-png.flaticon.com/512/7893/7893979.png" alt="Flight"
                                    class="img-fluid">
                            </div>
                            <div class="col-lg-9 text-start">
                                <!-- Flight Details -->
                                <div class="">
                                    <h4>Flight Details</h4>
                                    <p><strong>Name:</strong> <?= htmlspecialchars($package['airline']) ?></p>
                                    <p><strong>Flight Number:</strong>
                                        <?= htmlspecialchars($package['flight_number']) ?></p>
                                    <p><strong>Arrival:</strong> <?= htmlspecialchars($package['arrival_airport']) ?>
                                    </p>
                                    <p><strong>Departure:</strong>
                                        <?= htmlspecialchars($package['departure_airport']) ?></p>
                                    <p><strong>Arrival Time:</strong> <?= htmlspecialchars($package['arrival_time']) ?>
                                    </p>
                                    <p><strong>Departure Time:</strong>
                                        <?= htmlspecialchars($package['departure_time']) ?></p>
                                    <p><strong>Price:</strong> ₹<?= number_format($package['price'], 2) ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Package Images -->

                        <!-- Back Button -->
                        <div class="mt-4 text-center">
                            <a href="packages.php" class="btn btn-secondary">Back to Packages</a>
                        </div>
                    </div>

                </div>


                <!-- Booking Form Modal -->
                <div class="modal" id="bookingModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Enter Traveler Details</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <form id="bookingForm">
                                    <input type="hidden" name="package_id" id="package_id" value="<?= $package_id ?>">
                                    <input type="hidden" name="total_price" id="total_price"
                                        value="<?= $package['total_amount'] ?>">

                                    <div id="travelerFields"></div> <!-- Traveler Input Fields -->

                                    <button type="submit" class="btn btn-primary">Book Now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    document.getElementById("buyNowBtn").addEventListener("click", function () {
                        let totalPersons = <?= $package['total_persons'] ?>;
                        let travelerFields = document.getElementById("travelerFields");
                        travelerFields.innerHTML = "";

                        for (let i = 1; i <= totalPersons; i++) {
                            travelerFields.innerHTML += `
                            <div class="col-lg-6">
                                <h5>Traveler ${i}</h5>
                                <input type="text" name="travelers[${i}][name]" placeholder="Full Name" required class="form-control my-2">
                                <input type="number" name="travelers[${i}][age]" placeholder="Age" required class="form-control my-2">
                                <select name="travelers[${i}][gender]" required class="form-control my-2">
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <hr />
                        `;
                        }

                        $("#bookingModal").modal("show");
                    });

                    document.getElementById("bookingForm").addEventListener("submit", function (e) {
                        e.preventDefault();
                        let formData = new FormData(this);

                        fetch("book_package.php", {
                            method: "POST",
                            body: formData
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === "success") {
                                    alert("Booking Successful!");
                                    setTimeout(() => {
                                        window.location.href = "order_history.php";
                                    }, 3000);
                                } else {
                                    alert(data.message);
                                }
                            });
                    });
                </script>




            </div>
        </div>
    </div>
    <!-- Contact End -->

    <?php

    include 'Footer.php';

    ?>

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>


    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>